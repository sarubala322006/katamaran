Export visitors.db and events.log from your Google Colab runtime into this folder before submission.
