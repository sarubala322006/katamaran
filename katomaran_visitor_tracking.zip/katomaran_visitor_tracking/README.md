# Video Visitor Tracking with YOLO and InsightFace

## Overview
This prototype detects faces in a video with a YOLO face detector, generates face embeddings with InsightFace/ArcFace, assigns visitor IDs, saves face crops, and records inferred ENTRY/EXIT events in SQLite and `events.log`.

## Current implementation
- YOLO face detection (pretrained face model).
- InsightFace face embeddings (512-dimensional).
- Similarity-based visitor ID matching.
- Configurable frame skipping and similarity threshold.
- SQLite tables: `visitors` and `events`.
- Cropped face images and plain-text event log.

## Important limitations
- Visitor IDs are prototype estimates, not verified identities or a guaranteed count of unique people.
- Similarity matching may split one person into multiple IDs or merge similar-looking people.
- ENTRY/EXIT events are inferred from sampled video frames and a missing-detection threshold; they are not proof of physical entry/exit through a doorway.
- Timestamps are approximated from the video-processing start time and frame positions.
- The current notebook pipeline resets the SQLite tables at the start of a run.
- The InsightFace model pack may have license restrictions; verify permitted use before commercial deployment.

## Project structure
```text
katomaran_visitor_tracking/
├── README.md
├── requirements.txt
├── config.json
├── src/
│   └── pipeline.py
├── output/
│   ├── visitors.db       # add after exporting from Colab
│   └── events.log        # add after exporting from Colab
└── visitor_faces/        # add selected crops after exporting from Colab
```

## Environment
Recommended: Google Colab or Python 3.10/3.11. Model packages can have compatibility constraints with newer Python versions.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Download/place the YOLO face weights at the path configured in `config.json`.
3. Place your input video at the configured `video_path`.
4. Run:
   ```bash
   python src/pipeline.py
   ```

## Configuration
Edit `config.json`:
- `video_path`: input video path.
- `frame_skip`: process every Nth frame.
- `similarity_threshold`: cosine similarity threshold used for embedding matches.
- `exit_after_missing_samples`: number of sampled frames a visitor can be missing before an EXIT is inferred.
- `database_path`: SQLite database path.
- `face_images_folder`: directory for face crops.
- `events_log_path`: text event log path.

## Database schema
- `visitors(visitor_id, first_seen, face_image_path)`
- `events(event_id, visitor_id, event_type, timestamp, frame_number, face_image_path)`

## Demo
Add your recorded demo video URL here before submission.

## Submission checklist
- [ ] Export and include `visitors.db` and `events.log` from Colab.
- [ ] Export selected face crops if allowed by the task and privacy rules.
- [ ] Add the YOLO model download source and verify its license.
- [ ] Test on the provided sample video and include truthful results.
- [ ] Add demo video URL.
- [ ] Confirm all dependencies install in a clean runtime.
