"""
Prototype video visitor tracking pipeline.
Run in an environment where the YOLO face weights and InsightFace model are installed.
Check README.md for limitations and model licensing.
"""
import os
import json
import cv2
import sqlite3
import numpy as np
from datetime import datetime, timedelta
from ultralytics import YOLO
from insightface.app import FaceAnalysis

with open("config.json", encoding="utf-8") as f:
    cfg = json.load(f)

os.makedirs(cfg["face_images_folder"], exist_ok=True)
model = YOLO(cfg["yolo_model_path"])
face_app = FaceAnalysis(name="buffalo_l", providers=["CPUExecutionProvider"])
face_app.prepare(ctx_id=-1, det_size=(640, 640))

conn = sqlite3.connect(cfg["database_path"])
conn.execute("PRAGMA foreign_keys = ON")
conn.execute("""CREATE TABLE IF NOT EXISTS visitors (
    visitor_id TEXT PRIMARY KEY, first_seen TEXT NOT NULL, face_image_path TEXT)""")
conn.execute("""CREATE TABLE IF NOT EXISTS events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    visitor_id TEXT NOT NULL, event_type TEXT NOT NULL, timestamp TEXT NOT NULL,
    frame_number INTEGER, face_image_path TEXT,
    FOREIGN KEY(visitor_id) REFERENCES visitors(visitor_id))""")
# Prototype behavior: reset current-run records
conn.execute("DELETE FROM events")
conn.execute("DELETE FROM visitors")
conn.commit()
with open(cfg["events_log_path"], "w", encoding="utf-8") as f:
    f.write("Visitor event log\\n")

cap = cv2.VideoCapture(cfg["video_path"])
if not cap.isOpened():
    conn.close()
    raise RuntimeError(f"Cannot open video: {cfg['video_path']}")
fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
start_time = datetime.now().replace(microsecond=0)
frame_skip = max(1, int(cfg["frame_skip"]))
threshold = float(cfg["similarity_threshold"])
missing_limit = int(cfg["exit_after_missing_samples"])
registry, next_id = {}, 1
frame_no = sample_no = 0

def timestamp_for(frame):
    return (start_time + timedelta(seconds=frame / fps)).isoformat(sep=" ")

def log_event(visitor_id, event_type, frame, image_path):
    ts = timestamp_for(frame)
    conn.execute("""INSERT INTO events
        (visitor_id, event_type, timestamp, frame_number, face_image_path)
        VALUES (?, ?, ?, ?, ?)""",
        (visitor_id, event_type, ts, frame, image_path))
    with open(cfg["events_log_path"], "a", encoding="utf-8") as f:
        f.write(f"{ts} | {event_type} | {visitor_id} | frame={frame} | image={image_path or ''}\\n")

def crop_face(frame, face, visitor_id):
    x1, y1, x2, y2 = map(int, face.bbox)
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(frame.shape[1], x2), min(frame.shape[0], y2)
    if x2 <= x1 or y2 <= y1:
        return None
    path = os.path.join(cfg["face_images_folder"], f"{visitor_id}_frame_{frame_no:06d}.jpg")
    return path if cv2.imwrite(path, frame[y1:y2, x1:x2]) else None

while True:
    ok, frame = cap.read()
    if not ok:
        break
    if frame_no % frame_skip == 0:
        sample_no += 1
        for vid, d in registry.items():
            if d["active"] and sample_no - d["last_sample"] > missing_limit:
                d["active"] = False
                log_event(vid, "EXIT", frame_no, d["last_image"])

        # YOLO supplies face regions; InsightFace supplies embeddings.
        det = model.predict(frame, conf=0.25, verbose=False)[0]
        yolo_boxes = det.boxes.xyxy.cpu().numpy() if det.boxes is not None else []
        insight_faces = face_app.get(frame)
        # Keep InsightFace detections whose center overlaps a YOLO box, if any.
        faces = []
        for face in insight_faces:
            fx1, fy1, fx2, fy2 = face.bbox
            cx, cy = (fx1 + fx2) / 2, (fy1 + fy2) / 2
            if len(yolo_boxes) == 0 or any(
                x1 <= cx <= x2 and y1 <= cy <= y2
                for x1, y1, x2, y2 in yolo_boxes
            ):
                faces.append(face)

        candidates = []
        for i, face in enumerate(faces):
            for vid, d in registry.items():
                sim = float(np.dot(face.normed_embedding, d["embedding"]))
                if sim >= threshold:
                    candidates.append((sim, i, vid))
        candidates.sort(reverse=True)
        assigned, used = {}, set()
        for sim, i, vid in candidates:
            if i not in assigned and vid not in used:
                assigned[i], used = vid, used | {vid}

        for i, face in enumerate(faces):
            emb = face.normed_embedding
            if i in assigned:
                vid = assigned[i]
            else:
                vid = f"visitor_{next_id:03d}"
                next_id += 1
            image_path = crop_face(frame, face, vid)
            ts = timestamp_for(frame_no)
            if vid not in registry:
                registry[vid] = {
                    "embedding": emb.copy(), "first_seen": ts,
                    "last_sample": sample_no, "active": True,
                    "last_image": image_path
                }
                conn.execute("INSERT INTO visitors VALUES (?, ?, ?)", (vid, ts, image_path))
                log_event(vid, "ENTRY", frame_no, image_path)
            else:
                d = registry[vid]
                if not d["active"]:
                    log_event(vid, "ENTRY", frame_no, image_path)
                    d["active"] = True
                merged = (d["embedding"] + emb) / 2
                norm = np.linalg.norm(merged)
                if norm:
                    d["embedding"] = merged / norm
                d["last_sample"] = sample_no
                if image_path:
                    d["last_image"] = image_path
        conn.commit()
    frame_no += 1

cap.release()
for vid, d in registry.items():
    if d["active"]:
        log_event(vid, "EXIT", max(0, frame_no - 1), d["last_image"])
conn.commit()
conn.close()
print(f"Frames processed: {frame_no}")
print(f"Visitor IDs registered: {len(registry)}")
print(f"SQLite database: {cfg['database_path']}")
print(f"Event log: {cfg['events_log_path']}")
